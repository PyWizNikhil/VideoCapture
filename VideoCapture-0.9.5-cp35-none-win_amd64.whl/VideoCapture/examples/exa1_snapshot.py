from VideoCapture import Device

cam = Device()
cam.saveSnapshot('image.jpg', timestamp=3, boldfont=1)

from VideoCapture import Device
cam = Device(devnum=0)
print (cam.getDisplayName())
